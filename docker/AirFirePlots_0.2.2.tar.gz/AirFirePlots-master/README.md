# AirFirePlots R Package

## Background

The **AirFirePlots** package is being developed to provide a simple tool for
visualizing raster data from BlueSky and Weather Research & Forecasting model 
runs.

## Installation

...