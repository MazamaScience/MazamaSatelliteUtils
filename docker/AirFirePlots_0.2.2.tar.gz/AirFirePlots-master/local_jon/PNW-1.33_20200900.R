# Goal -- Washington and Oregon fire info for Sept. 09, 2020

# ----- Setup ------------------------------------------------------------------

library(ggplot2)
library(raster)

library(MazamaSpatialUtils)
MazamaSpatialUtils::setSpatialDataDir("~/Data/Spatial")

library(AirFireModeling)
AirFireModeling::setModelDataDir("~/Data/Bluesky")

library(AirFireWRF)
AirFireWRF::setWRFDataDir("~/Data/WRF")

library(AirFirePlots)

# ----- Configurable parameters ------------------------------------------------

modelRunHour <- 12
#xlim <- c(-124, -120)
#ylim <- c(43, 46)
xlim <- c(-123.5, -120.5)
ylim <- c(44, 46)

# ----- Load data --------------------------------------------------------------

# NOTE:  PNW-1.33km data is missing for Sep 09 & 10

# * Bluesky -----

bluesky_RB <- 
  AirFireModeling::bluesky_load(
    modelName = "PNW-1.33km",
    modelRun = 2020091100,
    modelMode = "forecast",
    xlim = xlim,
    ylim = ylim
  )

# * WRF -----

# wrfRaster <- 
#   wrf_load(
#     modelName = "PNW-1.33km",
#     modelRun = 2020091100,
#     modelRunHour = 1,
#     varNames = c("U10", "V10"),
#     xlim = xlim,
#     ylim = ylim,
#     res = 0.06
#   )

wrf_RB <- 
  AirFireWRF::example_PNW


# * Shapefiles -----

# * Location data -----


# ----- Assemble plot ----------------------------------------------------------

gg <- 
  
  # Base plot
  AirFirePlots::plot_base(
    title = sprintf("Bluesky Forecast for hour %d", modelRunHour),
    flab = "PM2.5 (ug/m3)",
    ratio = 1.4
  ) +
  
  # Add Bluesky forecast
  AirFirePlots::layer_raster(
    raster = bluesky_RB[[modelRunHour]]
  ) +
  
  # Add counties
  AirFirePlots::layer_counties(
    color = "gray80",
    xlim = xlim,
    ylim = ylim,
  ) +
  
  # Add states
  AirFirePlots::layer_states(
    color = "black",
    xlim = xlim,
    ylim = ylim
  ) +
  
  # Add WRF wind vectors
  layer_vectorField(
    raster = wrf_RB,
    uName = "U10",
    vName = "V10",
    arrowCount = 800,
    arrowWidth = 0.8,
    arrowColor = "black",
    xlim = xlim,
    ylim = ylim
  ) +

  # Set the color scale
  ggplot2::scale_fill_gradientn(
    colors = rev(grDevices::gray(seq(0, 1, length.out = 10))),
    na.value = "transparent"
  ) +
  
  # Zoom in to the requested region
  ggplot2::coord_cartesian(
    xlim = xlim, 
    ylim = ylim
  )


print(gg)

