library(AirFirePlots)
library(MazamaSpatialUtils)
library(ggplot2)
library(ggmap)

setSpatialDataDir("~/Data/Spatial")
loadSpatialData("NaturalEarthAdm1")

bbox <- c(left = -125.0323, bottom = 41.95484, right = -110.9465, top = 49.03729)
ggmap <- ggmap::get_stamenmap(bbox, zoom = 6)

fourCorners <- expand.grid(
  lon = as.numeric(attr(ggmap, "bb")[,c("ll.lon","ur.lon")]),
  lat = as.numeric(attr(ggmap, "bb")[,c("ll.lat","ur.lat")])
)

xmin <- attr(ggmap, "bb")$ll.lon
xmax <- attr(ggmap, "bb")$ur.lon
ymin <- attr(ggmap, "bb")$ll.lat
ymax <- attr(ggmap, "bb")$ur.lat

raster <- grDevices::as.raster(ggmap)

MapGeomRasterAnn <- ggproto(
  "GeomRasterAnn",
  Geom,
  extra_params = "",
  handle_na = function(data, params) {
   data
  },
  draw_panel = function(
    data, 
    panel_scales, 
    coord, 
    raster, 
    xmin, 
    xmax,
    ymin, 
    ymax, 
    interpolate = FALSE
  ) {
    corners <- data.frame(x = c(xmin, xmax), y = c(ymin, ymax))
    data <- coord$transform(corners, panel_scales)
    
    x_rng <- range(data$x, na.rm = TRUE)
    y_rng <- range(data$y, na.rm = TRUE)
    
    grid::rasterGrob(
      raster,
      x_rng[1], 
      y_rng[1],
      diff(x_rng), 
      diff(y_rng), 
      default.units = "native",
      just = c("left","bottom"), interpolate = interpolate
    )
  }
)

layer_map <- ggplot2::layer(
  data = fourCorners,
  mapping = aes(
    x = .data$lon,
    y = .data$lat
  ),
  stat = ggplot2::StatIdentity,
  position = ggplot2::PositionIdentity,
  geom = MapGeomRasterAnn,
  params = list(
    raster = raster,
    xmin = xmin,
    xmax = xmax,
    ymin = ymin,
    ymax = ymax,
    interpolate = TRUE
  )
)

ggplot() +
  coord_map(
    projection = "mercator",
    xlim = c(xmin, xmax),
    ylim = c(ymin, ymax)
  ) +
  layer_map +
  layer_states(
    stateCodes = c("WA"),
    color = "red"
  ) +
  layer_vectorField(
    raster = example_wrf,
    uName = "U10",
    vName = "V10"
  )
