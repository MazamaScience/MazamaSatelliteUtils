#' @name example_bluesky
#' @docType data
#' @keywords datasets
#' @title Example BlueSky model forecast
#' @format A single-layer RasterBrick containing 72 RasterLayers.
#' @description The \code{example_bluesky} dataset contains forecasted readings for 
#' PM2.5 across the Pacific Northwest from 1am 2020-09-15 to 12am 2020-09-18.
#' 
#' This dataset was generated on 2020-11-12 by running:
#'
#' \preformatted{
#' AirFireModeling::setModelDataDir("~/Data/BlueSky")
#' 
#' bluesky <- AirFireModeling::raster_load(
#'   modelName = "PNW-4km",
#'   modelRun = "20200714",
#'   xlim = c(-125, -111),
#'   ylim = c(42, 49)
#' )
#' 
#' example_bluesky <- bluesky$`PNW-4km_2020071400`$X1020.07.15.19.00.00
#' 
#' save(example_bluesky, file = "data/example_bluesky.rda", compress = "xz")
#' }
NULL
