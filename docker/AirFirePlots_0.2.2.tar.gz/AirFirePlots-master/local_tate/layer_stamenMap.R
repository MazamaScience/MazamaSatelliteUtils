layer_stamenMap <- function(
  stamenMap = NULL,
  xlim = NULL,
  ylim = NULL,
  alpha = 1
) {
  
}


if (FALSE) {
  library(AirFirePlots)
  library(MazamaSpatialUtils)
  library(ggplot2)
  library(ggmap)
  
  setSpatialDataDir("~/Data/Spatial")
  loadSpatialData("NaturalEarthAdm1")
  
  bbox <- c(left = -125.0323, bottom = 41.95484, right = -110.9465, top = 49.03729)
  ggmap <- ggmap::get_stamenmap(bbox, zoom = 7)

  
  # --------------------------
  
  # make base layer data.frame
  fourCorners <- expand.grid(
    lon = as.numeric(attr(ggmap, "bb")[,c("ll.lon","ur.lon")]),
    lat = as.numeric(attr(ggmap, "bb")[,c("ll.lat","ur.lat")])
  )
  
  # shorthand notation
  xmin <- attr(ggmap, "bb")$ll.lon
  xmax <- attr(ggmap, "bb")$ur.lon
  ymin <- attr(ggmap, "bb")$ll.lat
  ymax <- attr(ggmap, "bb")$ur.lat

  
  ggplot(aes(x = lon, y = lat), data = fourCorners) +
    geom_blank()+
    ggmap::inset_ggmap(
      ggmap
    ) +
    coord_map(
      xlim = c(xmin, xmax),
      ylim = c(ymin, ymax)
    ) +
    layer_states(
      stateCodes = c("WA"),
    )
}

if (FALSE) {

  bbox <- c(left = -125.0323, bottom = 30, right = -111.9465, top = 60.03729)
  ggmap <- ggmap::get_stamenmap(bbox, zoom = 5)
  
  ggmap(ggmap) +
    layer_states("WA")
  
  dummyPoints <- data.frame(
    x = c(xmin, xmax),
    y = c(ymin, ymax)
  )
  
  dummy <- ggplot2::geom_point(
    data = dummyPoints,
    ggplot2::aes(
      x = .data$x,
      y = .data$y
    ),
    color = "transparent",
    fill = "transparent"
  )
  
  plot_base() +
    dummy +
    annotation_raster(
      raster = grDevices::as.raster(ggmap),
      xmin = xmin,
      xmax = xmax,
      ymin = ymin,
      ymax = ymax,
      interpolate = TRUE
    ) +
    layer_states("WA")
}

# Draw map image on a coord_quickmap()
if (FALSE) {
  library(AirFirePlots)
  library(MazamaSpatialUtils)
  library(ggplot2)
  library(ggmap)
  
  setSpatialDataDir("~/Data/Spatial")
  loadSpatialData("NaturalEarthAdm1")
  
  bbox <- c(left = -125.0323, bottom = 41.95484, right = -110.9465, top = 49.03729)
  ggmap <- ggmap::get_stamenmap(bbox, zoom = 7)
  
  # shorthand notation
  xmin <- attr(ggmap, "bb")$ll.lon
  xmax <- attr(ggmap, "bb")$ur.lon
  ymin <- attr(ggmap, "bb")$ll.lat
  ymax <- attr(ggmap, "bb")$ur.lat
  
  ggplot() +
    coord_quickmap() +
    annotation_raster(
      raster = grDevices::as.raster(ggmap),
      xmin = xmin,
      xmax = xmax,
      ymin = ymin,
      ymax = ymax,
      interpolate = TRUE
    ) +
    layer_states(
      stateCodes = c("WA", "OR", "ID")
    )
}

# Convert raster to polygons and draw as geom_polygon on coord_map
# ERROR: Dow do I draw this SpatialPloygonsDataFrame?
if (FALSE) {
  MazamaSpatialUtils::setSpatialDataDir("~/Data/Spatial")
  MazamaSpatialUtils::loadSpatialData("NaturalEarthAdm1")
  
  polys <- raster::rasterToPolygons(example_wrf$HGT)
  
  ggplot2::ggplot() +
    ggplot2::coord_map(
      projection = "sinusoidal",
      xlim = c(-125, -117),
      ylim = c(45.5, 49)
    ) +
    ggplot2::geom_polygon(
      data = polys,
      ggplot2::aes(
        x = .data$x,
        y = .data$y,
        fill = .data$value,
        color = .data$value
      )
    ) +
    ggplot2::scale_fill_continuous() +
    ggplot2::scale_colour_continuous() +
    layer_states(stateCodes = c("WA"), color = "red")
}

# Convert raster to sf and draw as geom_sf on coord_map
# Cons: drawing any geom_sf overrides the coordniate system to coord_sf which is
# not Mercator
if (FALSE) {
  MazamaSpatialUtils::setSpatialDataDir("~/Data/Spatial")
  MazamaSpatialUtils::loadSpatialData("NaturalEarthAdm1")
  
  sp <- raster::rasterToPolygons(
    x = example_wrf
  )
  
  star <- stars::st_as_stars(example_wrf$HGT)
  poly <- sf::st_as_sf(star)
  
  ggplot2::ggplot() +
    ggplot2::coord_map(
      projection = "mercator",
      xlim = c(-130, -100),
      ylim = c(30, 60)
    ) +
    ggplot2::geom_sf(
      data = poly,
      mapping = ggplot2::aes(
        fill = .data$HGT,
        color = .data$HGT
      )
    ) +
    layer_states(
      stateCodes = c('WA', "OR", "ID", "CA"),
      color = "red"
    )
}

# Draw raster as a geom_tile
# Pros: can draw a raster on a coord_map in any projection
# Cons: how to display ggmap on top? super duper slow (minutes to generate), lines between polygons
if (FALSE) {
  MazamaSpatialUtils::setSpatialDataDir("~/Data/Spatial")
  MazamaSpatialUtils::loadSpatialData("NaturalEarthAdm1")
  
  rasterLayer <- example_wrf$HGT
  
  coords <- raster::xyFromCell(rasterLayer, seq_len(raster::ncell(rasterLayer)))
  readings <- raster::stack(as.data.frame(raster::getValues(rasterLayer)))
  names(readings) <- c("value", "variable")
  
  df <- cbind(coords, readings)
  
  ggplot2::ggplot() +
    ggplot2::coord_map(
      projection = "mercator",
      xlim = c(-125, -117),
      ylim = c(45.5, 49)
    ) +
    ggplot2::geom_tile(
      data = df,
      ggplot2::aes(
        x = .data$x,
        y = .data$y,
        fill = .data$value,
        color = .data$value
      )
    ) +
    ggplot2::scale_fill_continuous() +
    ggplot2::scale_colour_continuous() +
    layer_states(stateCodes = c("WA"), color = "red")
}

# Draw raster as ggmap::inset_raster
# Pros: Perfect alignment of map, raster, and lines. Almost instant
# Cons: Raster is not transparent, and I'm not sure how its fill scale is chosen
if (FALSE) {
  MazamaSpatialUtils::setSpatialDataDir("~/Data/Spatial")
  MazamaSpatialUtils::loadSpatialData("NaturalEarthAdm1")
  
  bbox <- c(left = -125, bottom = 42, right = -111, top = 70)
  ggmap <- ggmap::get_stamenmap(bbox, zoom = 6)
  
  xmin <- attr(ggmap, "bb")$ll.lon
  xmax <- attr(ggmap, "bb")$ur.lon
  ymin <- attr(ggmap, "bb")$ll.lat
  ymax <- attr(ggmap, "bb")$ur.lat
  
  ggmap::ggmap(ggmap) +
    ggmap::inset_raster(
      as.raster(example_wrf$HGT),
      xmin = example_wrf@extent@xmin,
      xmax = example_wrf@extent@xmax,
      ymin = example_wrf@extent@ymin,
      ymax = example_wrf@extent@ymax,
      interpolate = TRUE
    ) +
    layer_states(stateCodes = c("WA"), color = "red")
}

if (FALSE) {
  MazamaSpatialUtils::setSpatialDataDir("~/Data/Spatial")
  MazamaSpatialUtils::loadSpatialData("NaturalEarthAdm1")
  
  mapBox <- c(left = -125, bottom = 45.5, right = -120, top = 49.5)
  ggmap <- ggmap::get_stamenmap(mapBox, zoom = 8)
  
  xmin <- attr(ggmap, "bb")$ll.lon
  xmax <- attr(ggmap, "bb")$ur.lon
  ymin <- attr(ggmap, "bb")$ll.lat
  ymax <- attr(ggmap, "bb")$ur.lat
  
  rasterBox <- raster::extent(c(-122, -121, 47, 49))
  r <- raster::crop(example_wrf$HGT, rasterBox)
  
  ggmap::ggmap(ggmap) +
    ggmap::inset_raster(
      as.raster(r$HGT),
      xmin = r@extent@xmin,
      xmax = r@extent@xmax,
      ymin = r@extent@ymin,
      ymax = r@extent@ymax,
      interpolate = TRUE
    ) +
    layer_states(stateCodes = c("WA", "CA"), color = "red")
}
