#' @export
#' @title Create a plot layer for spatial points
#'
#' @param points A SpatialPointsDataFrame with columns: "x", "y", and "value".
#' @param size Size of the points.
#' @param lineWidth Width of point outline.
#' @param shape Shape of the points (0-25).
#' 
#' @details Points cannot be given a border color, as that would mean the points
#' would be filled using a fill scale likely already in use by a raster layer.
#'
#' @return A geom_point ggproto object.
#' 
#' @examples
#' \donttest{
#' library(AirFirePlots)
#' library(raster)
#' 
#' # Define raster bounds
#' xlim <- c(example_wrf@extent@xmin, example_wrf@extent@xmax)
#' ylim <- c(example_wrf@extent@ymin, example_wrf@extent@ymax)
#' 
#' # Generate rainfall SpatialPointsDataFrame
#' avgMonthRainfall <- data.frame(
#'   x = runif(20, min = xlim[1], max = xlim[2]),
#'   y = runif(20, min = ylim[1], max = ylim[2]),
#'   value = runif(20, min = 2, max = 20)
#' )
#' 
#' plot_base(
#'   title = "PNW Elevation & Rainfall",
#'   flab = "Elev (m)",
#'   clab = "Precip. (cm)",
#'   xlim = xlim,
#'   ylim = ylim
#' ) +  
#' layer_raster(
#'   raster = example_wrf,
#'   varName = "HGT"
#' ) +
#' layer_points(
#'   points = avgMonthRainfall,
#'   size = 3,
#'   lineWidth = 1,
#'   shape = 16
#' ) +
#' ggplot2::scale_fill_gradientn(
#'   colors = grDevices::terrain.colors(10),
#'   na.value = "transparent"
#' ) + 
#'  ggplot2::scale_color_gradient(
#'   low = "lightskyblue",
#'   high = "darkblue",
#'   na.value = "transparent"
#' )
#' }

layer_points <- function(
  points = NULL,
  size = 1,
  lineWidth = 1,
  shape = 16
) {
  
  # ----- Validate parameters --------------------------------------------------
  
  # TODO: enforce using SpatialPointsDataFrames
  
  if ( !is.numeric(size) )
    stop("Parameter 'size' must be a positive number")
  size <- max(size, 0)
  
  if ( !is.numeric(lineWidth) )
    stop("Parameter 'lineWidth' must be a positive number")
  lineWidth <- max(lineWidth, 0)
  
  if ( !is.numeric(shape) )
    stop("Parameter 'shape' must be an integer between [0-25]")
  shape <- max(floor(shape), 0)
  
  # ----- Create layer ---------------------------------------------------------
  
  layer <- ggplot2::geom_point(
    data = points,
    ggplot2::aes(
      x = .data$x,
      y = .data$y,
      color = .data$value
    ),
    size = size,
    stroke = lineWidth,
    shape = shape
  )
  
  return(layer)
  
}
