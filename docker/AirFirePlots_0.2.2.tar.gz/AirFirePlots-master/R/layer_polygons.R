#' @export
#' @title Create a plot layer for spatial polygons
#'
#' @param polygons A SpatialPolygonsDataFrame.
#' @param lineWidth Line width of polygon outlines.
#' @param color Outline color.
#' @param fill Fill color.
#'
#' @return A geom_polygon ggproto object.
#' 
#' @examples
#' \donttest{
#' library(AirFirePlots)
#' library(raster)
#' 
#' # Define raster bounds
#' xlim <- c(example_wrf@extent@xmin, example_wrf@extent@xmax)
#' ylim <- c(example_wrf@extent@ymin, example_wrf@extent@ymax)
#' 
#' MazamaSpatialUtils::setSpatialDataDir("~/Data/Spatial")
#' MazamaSpatialUtils::loadSpatialData("USCensusStates")
#' 
#' waPoly <- USCensusStates[USCensusStates@data$stateCode == "WA",]
#' 
#' plot_base(
#'   title = "PNW Elevation",
#'   flab = "Elev (m)",
#'   xlim = c(-125, -117),
#'   ylim = c(45.5, 49)
#' ) +
#' layer_raster(
#'   raster = example_wrf,
#'   varName = "HGT"
#' ) +
#' layer_polygons(
#'   polygons = waPoly,
#'   color = "black",
#'   fill = "transparent"
#' ) +
#' ggplot2::scale_fill_gradientn(
#'   colors = grDevices::terrain.colors(10),
#'   na.value = "transparent"
#' ) +
#' ggplot2::coord_cartesian(
#'   xlim = xlim, 
#'   ylim = ylim
#' )
#' }

layer_polygons <- function(
  polygons = NULL,
  lineWidth = 0.5,
  color = "black",
  fill = "transparent"
) {
  
  # ----- Validate parameters --------------------------------------------------
  
  # TODO: enforce using SpatialPolygonsDataFrames
  
  if ( !is.numeric(lineWidth) )
    stop("Parameter 'lineWidth' must be a positive number")
  lineWidth <- max(lineWidth, 0)
  
  # ----- Create layer ---------------------------------------------------------
  
  polygons@data$id <- rownames(polygons@data)
  points <- ggplot2::fortify(polygons, region = 'id')
  df <- merge(points, polygons@data, by = 'id')
  
  layer <- ggplot2::geom_polygon(
    data = df,
    ggplot2::aes(
      x = .data$long,
      y = .data$lat,
      group = .data$group
    ),
    size = lineWidth,
    color = color,
    fill = fill
  )
  
  return(layer)
  
}
