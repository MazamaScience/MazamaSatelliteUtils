#' @export
#' @title Create a plot layer for spatial icons
#'
#' @param coords A dataframe with columns: "x", "y".
#' @param iconName The name of the icon to use.
#' @param size Size of the icons.
#' @param nudge A numeric vector of the x and y offset of an icon from its 
#' coordinates.
#' 
#' @details Available icon names: "orangeFlame", "redFlame".
#'
#' @return A geom_image ggproto object.
#' 
#' @examples
#' \donttest{
#' library(AirFirePlots)
#' library(MazamaSpatialUtils)
#' library(PWFSLSmoke)
#' 
#' setSpatialDataDir("~/Data/Spatial")
#' loadSpatialData("NaturalEarthAdm1")
#' 
#' wa <- 
#'   loadLatest() %>%
#'   monitor_subset(stateCodes = "WA")
#' 
#' coords = data.frame(
#'   x = wa$meta$longitude,
#'   y = wa$meta$latitude
#' )
#' 
#' plot_base() +
#'   layer_states(
#'     stateCodes = "WA"
#'   ) +
#'   layer_icons(
#'    iconName = "orangeFlame",
#'    coords = coords,
#'    size = 0.03,
#'    nudge = c(0, 0)
#'   ) +
#'   ggplot2::geom_point(
#'     data = coords,
#'     ggplot2::aes(
#'       x = .data$x,
#'       y = .data$y
#'     ),
#'     size = 0.5
#'   )
#' }

layer_icons <- function(
  iconName = "redFlame",
  coords = NULL,
  size = 0.01,
  nudge = c(0, 0)
) {
  
  # ----- Validate parameters --------------------------------------------------
  
  if ( !is.character(iconName) )
    stop("Parameter 'iconName' must be a string")
  
  if ( !is.data.frame(coords) )
    stop("Parameter 'coords' must be a data frame numeric of x and y values")
  
  if ( !is.numeric(size) )
    stop("Parameter 'size' must be a number")
  
  if ( !is.numeric(nudge) )
    stop("Parameter 'nudge' must be a numeric vector")
  
  # ----- Create layer ---------------------------------------------------------
  
  # Test for absolute path
  if ( dirname(iconName) == "." ) {
    
    # Let users specify either "orangeFlame" or "orangeFlame.png"
    iconName <- stringr::str_replace(iconName, ".png", "")
    iconName <- paste0(iconName, ".png")
    
    pngFile <- base::system.file("icons", iconName, package = "PWFSLSmoke")
    
  } else {
    
    # Non-package icon, must be valid absolute path
    pngFile <- iconName
    
  }
  
  if ( pngFile == "" ) {
    stop("Cannot find package file 'inst/icons/", iconName, "'")
  }
  
  df <- data.frame(
    x = coords$x,
    y = coords$y,
    image = rep(pngFile, by = nrow(coords))
  )
  
  layer <-
    ggimage::geom_image(
      data = df,
      ggplot2::aes(
        x = .data$x,
        y = .data$y,
        image = .data$image
      ),
      size = size,
      position = ggplot2::position_nudge(nudge[1], nudge[2])
    )
  
  return(layer)
  
}
