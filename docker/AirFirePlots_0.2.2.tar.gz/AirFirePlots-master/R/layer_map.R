#' @export
#' @title Create a plot layer for a tile map image
#'
#' @param zoom Positive integer zoom factor. Higher values increase image 
#' detail.
#' @param xlim A vector of min & max longitude bounds.
#' @param ylim A vector of min & max latitude bounds.
#' 
#' @details All map images are Mercator-projected. This means they must be drawn
#' on a Mercator-projected coordinate system (`plot_base(project = TRUE)`) in 
#' order to correctly line up with other spatial geometry like rasters, lines, 
#' and polygons.
#'
#' @return A layer ggproto object.
#' 
#' @examples
#' \donttest{
#' library(AirFirePlots)
#' 
#' MazamaSpatialUtils::setSpatialDataDir("~/Data/Spatial")
#' MazamaSpatialUtils::loadSpatialData("NaturalEarthAdm1")
#'
#' plot_base(
#'   project = TRUE
#' ) +
#'   layer_map(
#'     zoom = 6,
#'     xlim = c(-125, -111),
#'     ylim = c(42, 49)
#'   ) +
#'   layer_states(
#'     stateCodes = c("WA"),
#'     color = "red"
#'   ) +
#'   layer_vectorField(
#'     raster = example_wrf,
#'     uName = "U10",
#'     vName = "V10",
#'     arrowScale = 0.04,
#'     headLength = ggplot2::unit(0.04, "inches"),
#'   )
#' }

layer_map <- function(
  zoom = NULL,
  xlim = NULL,
  ylim = NULL
) {
  
  bbox <- c(left = xlim[1], bottom = ylim[1], right = xlim[2], top = ylim[2])
  ggmap <- ggmap::get_stamenmap(bbox = bbox, zoom = zoom)
  
  fourCorners <- expand.grid(
    lon = as.numeric(attr(ggmap, "bb")[,c("ll.lon","ur.lon")]),
    lat = as.numeric(attr(ggmap, "bb")[,c("ll.lat","ur.lat")])
  )
  
  xmin <- attr(ggmap, "bb")$ll.lon
  xmax <- attr(ggmap, "bb")$ur.lon
  ymin <- attr(ggmap, "bb")$ll.lat
  ymax <- attr(ggmap, "bb")$ur.lat
  
  raster <- grDevices::as.raster(ggmap)
  
  MapGeomRasterAnn <- ggplot2::ggproto(
    "GeomRasterAnn",
    ggplot2::Geom,
    extra_params = "",
    handle_na = function(data, params) {
      data
    },
    draw_panel = function(
      data, 
      panel_scales, 
      coord, 
      raster, 
      xmin, 
      xmax,
      ymin, 
      ymax, 
      interpolate = FALSE
    ) {
      corners <- data.frame(x = c(xmin, xmax), y = c(ymin, ymax))
      data <- coord$transform(corners, panel_scales)
      
      x_rng <- range(data$x, na.rm = TRUE)
      y_rng <- range(data$y, na.rm = TRUE)
      
      grid::rasterGrob(
        raster,
        x_rng[1], 
        y_rng[1],
        diff(x_rng), 
        diff(y_rng), 
        default.units = "native",
        just = c("left", "bottom"), interpolate = interpolate
      )
    }
  )
  
  layer <- ggplot2::layer(
    data = fourCorners,
    mapping = ggplot2::aes(
      x = .data$lon,
      y = .data$lat
    ),
    stat = ggplot2::StatIdentity,
    position = ggplot2::PositionIdentity,
    geom = MapGeomRasterAnn,
    params = list(
      raster = raster,
      xmin = xmin,
      xmax = xmax,
      ymin = ymin,
      ymax = ymax,
      interpolate = TRUE
    )
  )
  
  return(layer)
  
}
