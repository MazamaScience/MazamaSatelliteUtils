#' @export
#' @title Create a plot layer for contour lines
#'
#' @param raster A RasterBrick or RasterLayer
#' @param varName The name of a raster variable.
#' @param breaks A numerical vector of contour line levels.
#' @param lineWidth Width of contour lines.
#' @param color Color of contour lines.
#' @param alpha Transparency of layer.
#' @param ... Additional parameters for ggplot2::geom_contour()
#'
#' @return A geom_contour ggproto object.
#' 
#' @examples
#' \donttest{
#' library(AirFirePlots)
#' library(raster)
#' 
#' plot_base(
#'   flab = "Elev (m)"
#' ) +  
#' layer_raster(
#'   raster = example_wrf,
#'   varName = "HGT"
#' ) +
#' layer_contours(
#'   raster = example_wrf,
#'   varName = "HGT",
#'   breaks = c(10, 100, 200, 500, 1000, 1500, 2000, 2500, 3000),
#'   lineWidth = 0.4,
#'   color = "black"
#' ) +
#' ggplot2::scale_fill_gradientn(
#'   colors = grDevices::terrain.colors(10),
#'   na.value = "transparent"
#' )
#' }

layer_contours <- function(
  raster = NULL,
  varName = NULL,
  breaks = NULL,
  lineWidth = 0.5,
  color = "black",
  alpha = 1,
  ...
) {
  
  # ----- Validate parameters --------------------------------------------------
  
  if ( "RasterBrick" %in% class(raster) ) {
    if ( raster::nlayers(raster) > 1 ) {
      
      if ( is.null(varName) )
        stop("Must set 'varName' parameter when raster has multiple layers")
      
      if ( !is.character(varName) )
        stop("Parameter 'varName' must be a character string")
      
      if ( !(varName %in% names(raster)))
        stop(paste0("No variable '", varName, "' in raster"))
      
      rasterLayer <- raster[[varName]]
    } else {
      rasterLayer <- raster
    }
  } else if ( "RasterLayer" %in% class(raster) ) {
    rasterLayer <- raster
  } else {
    stop("Parameter 'raster' must be either a RasterBrick or RasterLayer")
  }
  
  if ( !is.numeric(breaks) )
    stop("Parameter 'breaks' must be a numeric vector")
  
  if ( !is.numeric(lineWidth) )
    stop("Parameter 'lineWidth' must be a positive number")
  lineWidth <- max(lineWidth, 0)
  
  if ( !is.numeric(alpha) )
    stop("Parameter 'alpha' must be a number between 0 and 1")
  
  # Limit alpha to [0.0, 1.0] range
  alpha <- min(1, max(0, alpha))
  
  # ----- Create layer ---------------------------------------------------------
  
  coords <- raster::xyFromCell(rasterLayer, seq_len(raster::ncell(rasterLayer)))
  readings <- raster::stack(as.data.frame(raster::getValues(rasterLayer)))
  names(readings) <- c("value", "variable")
  
  df <- cbind(coords, readings)
  
  layer <- ggplot2::geom_contour(
    data = df,
    ggplot2::aes(
      x = .data$x,
      y = .data$y,
      z = .data$value
    ),
    breaks = breaks,
    size = lineWidth,
    color = color,
    alpha = alpha,
    ...
  )
  
  return(layer)
  
}
