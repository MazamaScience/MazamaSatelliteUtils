#' @export
#' @title Creates an empty plot
#'
#' @keywords internal
#'
#' @param title Title of plot.
#' @param xlab Label for x-axis.
#' @param ylab Label for y-axis.
#' @param clab Label for legend color scale.
#' @param flab Label for legend fill scale.
#' @param xlim A vector of min & max longitude bounds.
#' @param ylim A vector of min & max latitude bounds.
#' @param project Logical. If TRUE, the plot's coordinate system will be 
#' Mercator projected (accurate, but slow for drawing rasters). If FALSE, the 
#' coordinate system will use an approximation of Mercator projection (less 
#' accurate, but very fast for rasters).
#' @param expand Logical which takes effect when project=FALSE. If TRUE, it adds 
#' a small expansion factor to the plot's limits to ensure that data and axes 
#' don't overlap. If FALSE, limits are taken exactly from plot data or 
#' xlim/ylim.
#'
#' @return A ggplot object
#'
#' @examples
#' \donttest{
#' library(AirFirePlots)
#' library(raster)
#' 
#' xlim <- c(-125, -117)
#' ylim <- c(45.5, 49)
#' 
#' plot_base(
#'   title = "PNW Elevation",
#'   flab = "Elev (m)",
#'   xlim = xlim,
#'   ylim = ylim
#' ) +
#' layer_raster(
#'   raster = example_wrf,
#'   varName = "HGT"
#' ) +
#' layer_states(
#'   xlim = xlim,
#'   ylim = ylim,
#'   color = "red"
#' )
#' }

plot_base <- function(
  title = NULL,
  xlab = "Longitude",
  ylab = "Latitude",
  clab = NULL,
  flab = NULL,
  xlim = NULL,
  ylim = NULL,
  project = FALSE,
  expand = TRUE
) {
  
  # ----- Validate parameters --------------------------------------------------
  
  if ( !is.null(xlim) && !is.null(ylim) ) {
    if ( !is.numeric(xlim) || !is.numeric(ylim) )
      stop("Parameters 'xlim' and 'ylim' must be numeric vectors")
  }

  # Check if projection is logical
  
  # ----- Create scale ---------------------------------------------------------
  
  if ( project ) {
    
    coordSystem <- ggplot2::coord_map(
      projection = "mercator",
      xlim = xlim,
      ylim = ylim
    )
    
  } else {
    
    coordSystem <- ggplot2::coord_quickmap(
      xlim = xlim,
      ylim = ylim,
      expand = expand
    )
    
  }
  
  plot <-
    ggplot2::ggplot() +
    ggplot2::labs(
      title = title,
      x = xlab,
      y = ylab,
      color  = clab,
      fill = flab
    ) +
    coordSystem
  
  return(plot)
  
}
