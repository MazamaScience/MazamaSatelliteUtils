#' @export
#' @title Creates a composite plot
#'
#' @param raster A RasterBrick with one or more layers.
#' @param polys A SpatialPolygonsDataFrame.
#' @param states Logical for including state polygons or not.
#' @param bgName The name of the background raster layer.
#' @param ctrsName The name of the contour raster layer.
#' @param uName The name of the u component raster layer.
#' @param vName The name of the v component raster layer.
#' @param bgRasterBreaks A vector of raster values to use as palette breaks.
#' @param bgRasterPalette The name of a Brewer palette.
#' @param bgRasterPaletteDir Direction of the Brewer palette (1 = standard, 
#' -1 = reverse)
#' @param bgRasterColors Vector of colors to use for the background raster's 
#' n-color gradient.
#' @param bgRasterNaColor Color of na background raster values.
#' @param polyWidth Line thickness of spatial polygon outlines.
#' @param polyColor Color of spatial polygon outlines.
#' @param polyFill Color of spatial polygon interiors.
#' @param stateWidth Line thickness of state polygon outlines.
#' @param stateColor Color of state polygon outlines.
#' @param stateFill Color of state polygon interiors.
#' @param ctrsBreaks A numerical vector of contour line levels.
#' @param ctrsWidth Line thickness of contours.
#' @param ctrsColor Color of contour lines.
#' @param arrowCount Number of vector field arrows to draw.
#' @param arrowScale Scale factor of vector field arrow body length.
#' @param arrowWidth Line thickness of vector field arrows.
#' @param arrowColor Color of vector field arrows.
#' @param arrowHead Size of vector field arrowheads.
#' @param arrowAlpha Transparency of vector field arrows.
#' @param title Title of plot.
#' @param xlab Label for x-axis.
#' @param ylab Label for y-axis.
#' @param flab Label for legend fill scale.
#' @param xlim A vector of min & max longitude bounds.
#' @param ylim A vector of min & max latitude bounds.
#' @param project Logical. If TRUE, the plot's coordinate system will be 
#' Mercator projected (accurate, but slow for drawing rasters). If FALSE, the 
#' coordinate system will use an approximation of Mercator projection (less 
#' accurate, but very fast for rasters).
#' @param expand Logical. If TRUE, adds a small expansion factor to the plot's 
#' limits to ensure that data and axes don't overlap. If FALSE, limits are taken
#' exactly from plot data or xlim/ylim.
#' 
#' @details The background raster defaults to a gradient fill color scale when 
#' \code{breaks} is not specified. Otherwise, it will be colored using a 
#' discrete Brewer palette.
#'
#' @return A ggplot object.
#' 
#' 
#' @examples
#' \donttest{
#' library(AirFirePlots)
#' library(raster)
#' 
#' plot_composite(
#'   raster = example_wrf,
#'   bgName = "HGT",
#'   uName = "U10",
#'   vName = "V10",
#'   states = TRUE,
#'   stateColor = "red",
#'   arrowAlpha = 0.75,
#'   title = "PNW Elevation & Wind Velocity",
#'   flab = "Elev (m)",
#'   xlim = c(-125, -111),
#'   ylim = c(42, 49)
#' )
#' }

plot_composite <- function(
  raster = NULL,
  states = FALSE,
  polys = NULL,
  bgName = NULL,
  ctrsName = NULL,
  uName = NULL,
  vName = NULL,
  bgRasterBreaks = NULL,
  bgRasterPalette = "Blues",
  bgRasterPaletteDir = 1,
  bgRasterColors = grDevices::terrain.colors(10),
  bgRasterNaColor = "transparent",
  stateWidth = 0.5,
  stateColor = "black",
  stateFill = "transparent",
  polyWidth = 0.5,
  polyColor = "red",
  polyFill = "transparent",
  ctrsBreaks = NULL,
  ctrsWidth = 0.25,
  ctrsColor = "black",
  arrowCount = 1000,
  arrowScale = 0.05,
  arrowWidth = 0.3,
  arrowColor = "black",
  arrowHead = ggplot2::unit(0.05, "inches"),
  arrowAlpha = 1,
  title = NULL,
  xlab = NULL,
  ylab = NULL,
  flab = NULL,
  xlim = NULL,
  ylim = NULL,
  project = FALSE,
  expand = TRUE
) {
  
  # ----- Validate parameters --------------------------------------------------
  
  if ( !("RasterBrick" %in% class(raster)) )
    stop("Parameter 'raster' must be a RasterBrick with one or more layers")
  
  if ( !is.logical(states) )
    stop("Parameter 'states' must be either TRUE or FALSE")
  
  if ( !is.null(bgRasterBreaks) && !is.numeric(bgRasterBreaks) )
    stop("Parameter 'bgRasterBreaks' must be a numeric vector")
  
  availablePalettes <- rownames(RColorBrewer::brewer.pal.info)
  if ( !(bgRasterPalette %in% availablePalettes) )
    stop(sprintf("'%s' is not a recognized palette. Please see ?ggplot2::scale_colour_brewer."))
  
  if ( !(bgRasterPaletteDir %in% c(-1, 1)) )
    stop("Parameter 'bgRasterPaletteDir' must be either 1 or -1")
  
  if ( !is.character(bgRasterColors) )
    stop("Parameter 'bgRasterColors' must be a character vector")
  
  if ( is.null(title) && !is.null(raster) ) {
    title <- raster@title
  }
  
  # ----- Create scales --------------------------------------------------------
  
  # Default to a gradient fill scale if no bg raster breaks are specified
  if ( is.null(bgRasterBreaks) ) {
    
    fillScale <- ggplot2::scale_fill_gradientn(
      colors = bgRasterColors,
      na.value = bgRasterNaColor
    )
    
  } else {
    
    fillScale <- ggplot2::scale_fill_brewer(
      palette = bgRasterPalette,
      direction = bgRasterPaletteDir,
      na.value = bgRasterNaColor
    )
    
  }
  
  # ----- Create layers --------------------------------------------------------
  
  # Create a background raster layer
  if ( is.null(bgName) ) {
    rasterLayer <- NULL
  } else {
    rasterLayer <- layer_raster(
      raster = raster[[bgName]],
      breaks = bgRasterBreaks
    )
  }
  
  # Create a polygons layer
  if ( is.null(polys) ) {
    polysLayer <- NULL
  } else {
    polysLayer <- layer_polygons(
      polygons = polys,
      color = polyColor,
      fill = polyFill,
      lineWidth = polyWidth
    )
  }
  
  # Create a states polygons layer
  if ( !states ) {
    statesLayer <- NULL
  } else {
    statesLayer <- layer_states(
      color = stateColor,
      fill = stateFill,
      lineWidth = stateWidth,
      xlim = xlim,
      ylim = ylim
    )
  }
  
  # Create a contours layer
  if ( is.null(ctrsName) ) {
    contourLayer <- NULL
  } else {
    contourLayer <- layer_contours(
      raster = raster,
      varName = ctrsName,
      breaks = ctrsBreaks,
      color = ctrsColor,
      lineWidth = ctrsWidth
    )
  }
  
  # Create a vector field layer
  if ( is.null(uName) || is.null(vName) ) {
    vectorFieldLayer <- NULL
  } else {
    vectorFieldLayer <- layer_vectorField(
      raster = raster,
      uName = uName,
      vName = vName,
      arrowCount = arrowCount,
      arrowScale = arrowScale,
      headLength = arrowHead,
      lineWidth = arrowWidth,
      color = arrowColor,
      alpha = arrowAlpha,
      xlim = xlim,
      ylim = ylim
    )
    
    # Manually set the plot scale limits when there is no background raster 
    # layer
    if ( is.null(xlim) && is.null(ylim) ) {
      extent <- raster::extent(raster)
      xlim = c(extent@xmin, extent@xmax)
      ylim = c(extent@ymin, extent@ymax)
    }
  }
  
  # ----- Build the plot -------------------------------------------------------

  plot <-
    plot_base(
      title = title,
      xlab = xlab,
      ylab = ylab,
      flab = flab,
      xlim = xlim,
      ylim = ylim,
      project = project,
      expand = expand
    ) +
    rasterLayer +
    polysLayer +
    statesLayer +
    contourLayer + 
    vectorFieldLayer +
    fillScale

  return(plot)
  
}
