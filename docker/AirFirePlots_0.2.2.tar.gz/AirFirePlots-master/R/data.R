#' @name example_wrf
#' @docType data
#' @keywords datasets
#' @title Example WRF model forecast
#' @format RasterBrick containing 4 RasterLayers.
#' @description The \code{example_wrf} dataset contains WRF model predictions 
#' for temperature (\code{TSK}), elevation (\code{HGT}), and wind velocity 
#' (\code{U10} & \code{V10}) across the Pacific Northwest 7 hours after 12pm on
#' July 15, 2020.
#' 
#' This dataset was generated on 2020-10-27 by running:
#'
#' \preformatted{
#' example_wrf <- AirFireWRF::wrf_load(
#'   localPath = "~/Data/WRF/wrfout_d3-2020071512-f07-0000.nc",
#'   varNames = c("HGT", "TSK", "U10", "V10"),
#'   res = 0.06,
#'   xlim = c(-125, -111),
#'   ylim = c(42, 49)
#' )
#' 
#' # Have to manually set the title since the filename format is outdated
#' example_wrf@title <- "WRF PNW-4km 2020-07-15 12 PM, forecast hour 7"
#' 
#' save(example_wrf, file = "data/example_wrf.rda", compress = "xz")
#' }
NULL

#' @name example_bluesky
#' @docType data
#' @keywords datasets
#' @title Example BlueSky model forecast
#' @format RasterLayer
#' @description The \code{example_bluesky} dataset contains forecasted PM2.5 
#' readings across the Pacific Northwest at 7pm on 2020-09-15.
#' 
#' This dataset was generated on 2020-12-21 by running:
#'
#' \preformatted{
#' AirFireModeling::setModelDataDir("~/Data/BlueSky")
#' 
#' bluesky <- AirFireModeling::raster_load(
#'   modelName = "PNW-4km",
#'   modelRun = "20200714",
#'   xlim = c(-125, -111),
#'   ylim = c(42, 49)
#' )
#' 
#' example_bluesky <- bluesky$`PNW-4km_2020071400`$X1020.07.15.19.00.00
#' 
#' save(example_bluesky, file = "data/example_bluesky.rda", compress = "xz")
#' }
NULL