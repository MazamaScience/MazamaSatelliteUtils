#' @export
#' @title Creates a plot for a single raster layer
#'
#' @param raster A RasterBrick or RasterLayer.
#' @param varName The name of a raster variable.
#' @param breaks A vector of raster values to use as palette breaks.
#' @param naRemove Logical determining whether NA cells should be removed or not.
#' @param palette The name of a Brewer palette.
#' @param paletteDir Direction of the Brewer palette (1 = standard, -1 = reverse)
#' @param colors A vector of colors to use for n-color gradient.
#' @param naColor Color for na raster values.
#' @param title Title of plot.
#' @param xlab Label for x-axis.
#' @param ylab Label for y-axis.
#' @param flab Label for legend fill scale.
#' @param xlim A vector of min & max longitude bounds.
#' @param ylim A vector of min & max latitude bounds.
#' @param project Logical. If TRUE, the plot's coordinate system will be 
#' Mercator projected (accurate, but slow for drawing rasters). If FALSE, the 
#' coordinate system will use an approximation of Mercator projection (less 
#' accurate, but very fast for rasters).
#' @param expand Logical. If TRUE, adds a small expansion factor to the plot's 
#' limits to ensure that data and axes don't overlap. If FALSE, limits are taken
#' exactly from plot data or xlim/ylim.
#'
#' @details The raster defaults to a gradient fill color scale when 
#' \code{breaks} is not specified. Otherwise, it will be colored using a 
#' discrete Brewer palette.
#'
#' @return A ggplot object.
#' 
#' @examples
#' \donttest{
#' library(AirFirePlots)
#' library(raster)
#' 
#' # With gradient fill
#' plot_raster(
#'   raster = example_wrf,
#'   varName = "HGT",
#'   flab = "Elev (m)"
#' )
#' 
#' # With discrete palette fill
#' plot_raster(
#'   raster = example_wrf,
#'   varName = "HGT",
#'   breaks = c(0, 100, 500, 1000, 1500, 2000, Inf),
#'   flab = "Elev (m)"
#' )
#' }

plot_raster <- function(
  raster = NULL,
  varName = NULL,
  naRemove = FALSE,
  breaks = NULL,
  palette = "Blues",
  paletteDir = 1,
  colors = grDevices::terrain.colors(10),
  naColor = "transparent",
  title = NULL,
  xlab = NULL,
  ylab = NULL,
  flab = NULL,
  xlim = NULL,
  ylim = NULL,
  project = FALSE,
  expand = TRUE
) {
  
  # ----- Validate parameters --------------------------------------------------
  
  if ( !is.null(breaks) && !is.numeric(breaks) )
    stop("Parameter 'breaks' must be a numeric vector")
  
  availablePalettes <- rownames(RColorBrewer::brewer.pal.info)
  if ( !(palette %in% availablePalettes) )
    stop(sprintf("'%s' is not a recognized palette. Please see ?ggplot2::scale_colour_brewer."))
  
  if ( !(paletteDir %in% c(-1, 1)) )
    stop("Parameter 'direction' must be either 1 or -1")
  
  if ( !is.character(colors) )
    stop("Parameter 'colors' must be a character vector")
  
  if ( is.null(title) && !is.null(raster) ) {
    title <- raster@title
  }
  
  # ----- Create scale ---------------------------------------------------------
  
  # Default to a gradient fill scale if no breaks are specified
  if ( is.null(breaks) ) {
    
    fillScale <- ggplot2::scale_fill_gradientn(
      colors = colors,
      na.value = naColor
    )
    
  } else {
    
    fillScale <- ggplot2::scale_fill_brewer(
      palette = palette,
      direction = paletteDir,
      na.value = naColor
    )
    
  }
  
  # ----- Create layers --------------------------------------------------------
  
  plot <-
    plot_base(
      title = title,
      xlab = xlab,
      ylab = ylab,
      flab = flab,
      xlim = xlim,
      ylim = ylim,
      project = project,
      expand = expand
    ) +
    layer_raster(
      raster = raster,
      varName = varName,
      naRemove = naRemove,
      breaks = breaks,
      alpha = 1
    ) +
    fillScale
  
  return(plot)
  
}
