#' @export
#' @importFrom rlang .data
#' 
#' @title Create a plot layer for a raster
#'
#' @param raster A RasterBrick or RasterLayer.
#' @param varName The name of a raster variable.
#' @param naRemove Logical determining whether NA cells should be removed or not.
#' @param breaks A vector of raster values to use as palette breaks.
#' @param alpha Transparency of layer.
#'
#' @return A geom_tile ggproto object.
#' 
#' @examples
#' \donttest{
#' library(AirFirePlots)
#' library(raster)
#' 
#' plot_base(
#'   flab = "Elev (m)"
#' ) +
#' layer_raster(
#'   raster = example_wrf,
#'   varName = "HGT"
#' )
#' }

layer_raster <- function(
  raster = NULL,
  varName = NULL,
  naRemove = FALSE,
  breaks = NULL,
  alpha = 1
) {
  
  # ----- Validate parameters --------------------------------------------------
  
  if ( "RasterBrick" %in% class(raster) ) {
    if ( raster::nlayers(raster) > 1 ) {
      
      if ( is.null(varName) )
        stop("Must set 'varName' parameter when raster has multiple layers")
      
      if ( !is.character(varName) )
        stop("Parameter 'varName' must be a character string")
      
      if ( !(varName %in% names(raster)))
        stop(paste0("No variable '", varName, "' in raster"))
      
      rasterLayer <- raster[[varName]]
    } else {
      rasterLayer <- raster
    }
  } else if ( "RasterLayer" %in% class(raster) ) {
    rasterLayer <- raster
  } else {
    stop("Parameter 'raster' must be either a RasterBrick or RasterLayer")
  }
  
  if ( !is.logical(naRemove) )
    stop("Parameter 'naRemove' must be either TRUE or FALSE")
  
  if ( !is.null(breaks) && !is.numeric(breaks) )
    stop("Parameter 'breaks' must be a numeric vector")
  
  if ( !is.numeric(alpha) )
    stop("Parameter 'alpha' must be a number between 0 and 1")
  
  # Limit alpha to [0.0, 1.0] range
  alpha <- min(1, max(0, alpha))
  
  # ----- Create layer ---------------------------------------------------------
  
  # Match each cell's value to its location
  cellCoords <- raster::xyFromCell(rasterLayer, seq_len(raster::ncell(rasterLayer)))
  cellValues <- as.data.frame(raster::getValues(rasterLayer))
  names(cellValues) <- c("value")
  cellsDF <- cbind(cellCoords, cellValues)
  
  if ( naRemove ) cellsDF <- stats::na.omit(cellsDF)
  
  layer <- ggplot2::geom_tile(
    data = cellsDF,
    ggplot2::aes(
      x = .data$x,
      y = .data$y,
      fill = if ( is.null(breaks) ) {
        .data$value
      } else {
        cut(.data$value, breaks, include.lowest = TRUE)
      }
    ),
    alpha = alpha
  )
  
  return(layer)
  
}
