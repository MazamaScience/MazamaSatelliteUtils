#' @export
#' @title Create a plot layer for state county polygons
#'
#' @param lineWidth Line width of county borders.
#' @param color Line color of county borders.
#' @param fill Fill color of county polygons.
#' @param xlim A vector of min & max longitude bounds.
#' @param ylim A vector of min & max latitude bounds.
#'
#' @return A geom_polygon ggproto object.
#' 
#' @examples
#' \donttest{
#' library(AirFirePlots)
#' library(raster)
#' 
#' # Define raster bounds
#' xlim <- c(example_wrf@extent@xmin, example_wrf@extent@xmax)
#' ylim <- c(example_wrf@extent@ymin, example_wrf@extent@ymax)
#' 
#' plot_base(
#'   title = "PNW Elevation",
#'   flab = "Elev (m)"
#' ) +
#' layer_raster(
#'   raster = example_wrf,
#'   varName = "HGT"
#' ) +
#' layer_counties(
#'   xlim = xlim,
#'   ylim = ylim
#' ) +
#' ggplot2::scale_fill_gradientn(
#'   colors = grDevices::terrain.colors(10),
#'   na.value = "transparent"
#' ) +
#' ggplot2::coord_cartesian(
#'   xlim = xlim, 
#'   ylim = ylim
#' )
#' }

layer_counties <- function(
  lineWidth = 0.5,
  color = "black",
  fill = "transparent",
  xlim = NULL,
  ylim = NULL
) {
  
  # ----- Validate parameters --------------------------------------------------
  
  if ( !is.numeric(lineWidth) )
    stop("Parameter 'lineWidth' must be a positive number")
  lineWidth <- max(lineWidth, 0)
  
  if ( !is.numeric(xlim) || !is.numeric(ylim) )
    stop("Parameters 'xlim' and 'ylim' must be numeric vectors")
  
  # ----- Create layer ---------------------------------------------------------
  
  counties <- ggplot2::map_data(
    map = "county",
    xlim = xlim,
    ylim = ylim
  )
  
  layer <- ggplot2::geom_polygon(
    data = counties,
    ggplot2::aes(
      y = .data$lat,
      x = .data$long,
      group = .data$group
    ),
    size = lineWidth,
    fill = fill,
    color = color
  )
  
  return(layer)
  
}
