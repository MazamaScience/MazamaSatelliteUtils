#' @export
#' @title Create a plot layer for state polygons
#'
#' @param stateCodes A character vector of U.S. state codes.
#' @param xlim A vector of min & max longitude bounds.
#' @param ylim A vector of min & max latitude bounds.
#' @param lineWidth Line width of state borders.
#' @param color Line color of state borders.
#' @param fill Fill color of state polygons.
#' @param ... Additional parameters for ggplot2::map_data()
#'
#' @return A geom_polygon ggproto object.
#' 
#' @examples
#' \donttest{
#' library(AirFirePlots)
#' library(MazamaSpatialUtils)
#' library(raster)
#' 
#' # Define raster bounds
#' xlim <- c(example_wrf@extent@xmin, example_wrf@extent@xmax)
#' ylim <- c(example_wrf@extent@ymin, example_wrf@extent@ymax)
#' 
#' plot_base(
#'   title = "PNW Elevation",
#'   flab = "Elev (m)"
#' ) +
#' layer_raster(
#'   raster = example_wrf,
#'   varName = "HGT"
#' ) +
#' layer_states(
#'   xlim = xlim,
#'   ylim = ylim,
#'   lforce = "e"
#' ) +
#' ggplot2::scale_fill_gradientn(
#'   colors = grDevices::terrain.colors(10),
#'   na.value = "transparent"
#' )
#' 
#' setSpatialDataDir("~/Data/Spatial")
#' loadSpatialData("NaturalEarthAdm1")
#' 
#' plot_base(
#'   title = "PNW Elevation",
#'   flab = "Elev (m)"
#' ) +
#' layer_raster(
#'   raster = example_wrf,
#'   varName = "HGT"
#' ) +
#' layer_states(
#'   stateCodes = c("WA", "OR", "ID")
#' ) +
#' ggplot2::scale_fill_gradientn(
#'   colors = grDevices::terrain.colors(10),
#'   na.value = "transparent"
#' ) +
#' ggplot2::coord_cartesian(
#'   xlim = xlim, 
#'   ylim = ylim
#' )
#' }

layer_states <- function(
  stateCodes = NULL,
  xlim = NULL,
  ylim = NULL,
  lineWidth = 0.5,
  color = "black",
  fill = "transparent",
  ...
) {
  
  # ----- Validate parameters --------------------------------------------------
  
  isUsingStateCodes <- FALSE
  
  if ( is.character(stateCodes)) {
    isUsingStateCodes <- TRUE
    
    if ( is.numeric(xlim) && is.numeric(ylim) ) {
      print("Using specified state codes over xlim/ylim area")
    }
  } else if (!is.numeric(xlim) || !is.numeric(ylim)) {
    stop("Must provide parameter 'stateCodes' or parameters xlim' & 'ylim'")
  }
  
  if ( !is.numeric(lineWidth) )
    stop("Parameter 'lineWidth' must be a positive number")
  lineWidth <- max(lineWidth, 0)
  
  # ----- Create layer ---------------------------------------------------------
  
  if ( isUsingStateCodes ) {
    
    stateNames <- tolower(
      MazamaSpatialUtils::codeToState(
        stateCodes = stateCodes,
        countryCodes = "US"
      )
    )
    
    stateData <- ggplot2::map_data(
      map = "state",
      region = stateNames,
      ... = ...
    )
    
  } else {
    
    stateData <- ggplot2::map_data(
      map = "state",
      xlim = xlim,
      ylim = ylim,
      ... = ...
    )
    
  }
  
  layer <- ggplot2::geom_polygon(
    data = stateData,
    ggplot2::aes(
      y = .data$lat,
      x = .data$long,
      group = .data$group
    ),
    size = lineWidth,
    fill = fill,
    color = color
  )
  
  return(layer)
  
}
