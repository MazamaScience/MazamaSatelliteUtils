#' @export
#' @title Create a plot layer for a vector field
#'
#' @param raster A RasterBrick with layers for u/v vector components.
#' @param uName The name of the u component layer.
#' @param vName The name of the v component layer.
#' @param arrowCount Number of arrows to draw.
#' @param arrowScale Scale factor of arrow length.
#' @param headLength Length of arrow head from tip to base as a ggplot::unit().
#' @param headAngle Angle formed by the arrow head in degrees.
#' @param lineWidth Line width of arrows.
#' @param color Color of arrows.
#' @param alpha Transparency of layer.
#' @param xlim A vector of min & max longitude bounds.
#' @param ylim A vector of min & max latitude bounds.
#'
#' @return A geom_segment ggproto object.
#' 
#' @examples
#' \donttest{
#' library(AirFirePlots)
#' 
#' MazamaSpatialUtils::setSpatialDataDir("~/Data/Spatial")
#' MazamaSpatialUtils::loadSpatialData("NaturalEarthAdm1")
#' 
#' plot_base(
#'   flab = "Elev (m)"
#' ) +
#'   ggplot2::scale_fill_gradientn(
#'     colors = grDevices::terrain.colors(10),
#'     na.value = "transparent"
#'   ) +
#'   layer_raster(
#'     raster = example_wrf,
#'     varName = "HGT"
#'   ) +
#'   layer_states(
#'     stateCodes = c("WA", "OR", "ID"),
#'     lineWidth = 0.5,
#'     color = "red"
#'   ) +
#'   layer_vectorField(
#'     raster = example_wrf,
#'     uName = "U10",
#'     vName = "V10"
#'   )
#' }

layer_vectorField <- function(
  raster = NULL,
  uName = NULL,
  vName = NULL,
  arrowCount = 1000,
  arrowScale = 0.05,
  headLength = ggplot2::unit(0.05, "inches"),
  headAngle = 60,
  lineWidth = 0.3,
  color = "black",
  alpha = 1,
  xlim = NULL,
  ylim = NULL
) {
  
  # ----- Validate parameters --------------------------------------------------
  
  if ( !("RasterBrick" %in% class(raster)) )
    stop("Parameter 'raster' must be a RasterBrick")
  
  if ( !is.character(uName) || !is.character(vName) )
    stop("Parameters 'uName' and 'vName' must be character strings")
  
  if ( !(uName %in% names(raster)) ) 
    stop(paste0("No variable '", uName, "' in raster"))
  
  if ( !(vName %in% names(raster)) )
    stop(paste0("No variable '", vName, "' in raster"))
  
  if ( !is.numeric(arrowCount) )
    stop("Parameter 'arrowCount' must be a positive integer")
  arrowCount <- max(floor(arrowCount), 0)
  
  if ( !is.numeric(arrowScale) )
    stop("Parameter 'arrowScale' must be a positive number")
  arrowScale <- max(arrowScale, 0)
  
  if ( !("unit" %in% class(headLength)) )
    stop("Parameter 'headLength' must be a positive unit number")
  headLength <- max(headLength, ggplot2::unit(0, "inches"))
  
  if ( !is.numeric(headAngle) )
    stop("Parameter 'headAngle' must be a positive number between 0 and 180")
  headAngle <- min(max(headAngle, 0), 180)
  
  if ( !is.numeric(lineWidth) )
    stop("Parameter 'arrowWidth' must be a positive number")
  lineWidth <- max(lineWidth, 0)
  
  if ( !is.numeric(alpha) )
    stop("Parameter 'alpha' must be a number between 0 and 1")
  alpha <- min(1, max(0, alpha))
  
  if ( !is.null(xlim) && !is.null(ylim) ) {
    if ( !is.numeric(xlim) || !is.numeric(ylim) ) {
      stop("Parameters 'xlim' and 'ylim' must be numeric vectors")
    }
  }
  
  # ----- Define arrows --------------------------------------------------------
  
  # Define region bounds of the vector field
  extent <- if (is.null(xlim) || is.null(ylim)) {
    NULL
  } else {
    raster::extent(xlim, ylim)
  }
  
  # Subsample the raster for the desired number of arrows
  subSample <- data.frame(
    raster::sampleRegular(
      x = raster,
      size = arrowCount,
      ext = extent,
      xy = TRUE
    )
  )
  
  # Define arrow line segment start/end coordinates
  df <- data.frame(
    startX = subSample$x,
    startY = subSample$y,
    endX = subSample$x + subSample[[uName]] * arrowScale, # This is adding meters to degrees...
    endY = subSample$y + subSample[[vName]] * arrowScale  # This is adding meters to degrees...
  )
  
  # ----- Create layer ---------------------------------------------------------
  
  layer <- ggplot2::geom_segment(
    data = df,
    mapping = ggplot2::aes(
      x = .data$startX, 
      y = .data$startY,
      xend = .data$endX,
      yend = .data$endY
    ),
    arrow = ggplot2::arrow(
      angle = headAngle / 2,
      length = headLength
    ),
    size = lineWidth,
    color = color,
    alpha = alpha
  )
  
  return(layer)
  
}

# Draw on projected grid
if (FALSE) {
  library(AirFirePlots)
  
  MazamaSpatialUtils::setSpatialDataDir("~/Data/Spatial")
  MazamaSpatialUtils::loadSpatialData("NaturalEarthAdm1")
  
  lowRes <- raster::aggregate(example_wrf$HGT, fact = 4)
  
  coords <- raster::xyFromCell(lowRes, seq_len(raster::ncell(lowRes)))
  readings <- raster::stack(as.data.frame(raster::getValues(lowRes)))
  names(readings) <- c("value", "variable")
  df <- cbind(coords, readings)
  
  ggplot2::ggplot() + 
    ggplot2::coord_map(
      projection = "mercator",
      xlim = c(-125, -117),
      ylim = c(45.5, 49)
    ) +
    ggplot2::scale_fill_gradientn(
      colors = grDevices::terrain.colors(10),
      na.value = "transparent"
    ) +
    ggplot2::geom_tile(
      data = df,
      ggplot2::aes(
        x = .data$x,
        y = .data$y,
        fill = .data$value
      )
    ) +
    layer_states(
      stateCodes = "WA",
      color = "red",
      lineWidth = 0.6,
    ) +
    layer_vectorField(
      raster = example_wrf,
      uName = "U10",
      vName = "V10",
      arrowCount = 1000,
      arrowScale = 0.02,
      headLength = ggplot2::unit(0.02, "inches"),
      headAngle = 20,
      xlim = c(-124.6, -122.3),
      ylim = c(47.3, 48.6)
    )
  
}

