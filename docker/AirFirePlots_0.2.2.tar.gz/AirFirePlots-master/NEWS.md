# AirFirePlots 0.2.2

* The `example_bluesky` dataset is saved properly and can be plotted now.
* Removed **rasterVis** dependency.
* Removed "Non-map plots" section of the "AirFirePlots" vignette.

# AirFirePlots 0.2.1

* `plot_base()` now uses either a precise or an approximated Mercator-projected
coordinate system (depending on user preference).
* `layer_raster()` now creates a `ggplot2::geom_tile` element instead of a 
`ggplot2::geom_raster`.
* Added the Developer Style Guide Vignette.
* Removed the **ggplotify** dependency.

# AirFirePlots 0.2.0

* Added the `layer_map()` function.
* `layer_vectorField()` now returns a `ggplot2::geom_segment` element rather 
than an `annotation_custom`.

# AirFirePlots 0.1.8

* Added "Plotting Map Tiles" article.

# AirFirePlots 0.1.7

* Changed `example_PNW` example dataset to `example_WRF`.
* Added `example_bluesky` example dataset.
* The `raster` parameter in `plot_composite()` is no longer allowed to be 
anything but a *RasterBrick*.
* Added `expand` parameter to `plot_base()`, `plot_raster()`, and 
`plot_composite()`.

# AirFirePlots 0.1.6

* Added the `layer_icons()` function.
* Fixed error in `layer_states()` example.

# AirFirePlots 0.1.5

* Added `naRemove` parameter to `layer_raster`. This can be used to bypass the 
issue of NA cells showing up as white even when a raster's fill scale sets 
`na.value = "transparent"`.
* Added `stateCodes` and `...` parameters to `layer_states()`.

# AirFirePlots 0.1.4

* `plot_base()` is now an exported function.
* `plot_base()` is now used in place of explicit **ggplot** calls in articles
and vignettes.
* All `layer_~()` functions now include examples.

# AirFirePlots 0.1.3

* More robust parameter validation in all `plot_~()` and `layer_~()` functions.
* Removed the `values` parameter from `plot_raster()` and the `bgRasterValues`
parameter from `plot_composite()`.
* Vector field layers now function as **ggplot** *geom* objects so they can
influence plot bounds.

# AirFirePlots 0.1.2

* Additional `plot_raster()` example to demonstrate using a gradient vs. a 
discrete palette fill scale.
* Added the "Building Layered Maps" article.
* Added the initial draft of the "Getting Started" vignette.

# AirFirePlots 0.1.1

* Added parameters to `layer_points()` for line width and shape. 

# AirFirePlots 0.1.0

* Initial Release
